import telebot
from telebot import types
import json
import random
import os
from datetime import datetime

from server import keep_alive

TOKEN = '8113212393:AAFwiF13ddMHaCvOOb-joitlEpewxYPvlPU'
bot = telebot.TeleBot(TOKEN)

BALANCE_FILE = 'balances.json'
DAILY_FILE = 'last_daily.json'
DUEL_HISTORY_FILE = 'duel_history.json'

START_BALANCE = 1000
MIN_BET = 300
DAILY_REWARD = 500

pending_duels = {}

# Балансы
def load_balances():
    if not os.path.exists(BALANCE_FILE):
        return {}
    with open(BALANCE_FILE, 'r') as f:
        return json.load(f)

def save_balances(balances):
    with open(BALANCE_FILE, 'w') as f:
        json.dump(balances, f)

def get_balance(user_id):
    balances = load_balances()
    return balances.get(str(user_id), START_BALANCE)

def set_balance(user_id, amount):
    balances = load_balances()
    balances[str(user_id)] = amount
    save_balances(balances)

def add_balance(user_id, amount):
    set_balance(user_id, get_balance(user_id) + amount)

def reduce_balance(user_id, amount):
    set_balance(user_id, get_balance(user_id) - amount)

# Daily reward
def load_daily_data():
    if not os.path.exists(DAILY_FILE):
        return {}
    with open(DAILY_FILE, 'r') as f:
        return json.load(f)

def save_daily_data(data):
    with open(DAILY_FILE, 'w') as f:
        json.dump(data, f)

# Duel limit
def load_duel_history():
    if not os.path.exists(DUEL_HISTORY_FILE):
        return {}
    with open(DUEL_HISTORY_FILE, 'r') as f:
        return json.load(f)

def save_duel_history(data):
    with open(DUEL_HISTORY_FILE, 'w') as f:
        json.dump(data, f)

def can_duel(user_id):
    history = load_duel_history()
    now = datetime.now().timestamp()
    one_hour_ago = now - 3600

    user_id = str(user_id)
    if user_id not in history:
        history[user_id] = []

    recent = [t for t in history[user_id] if t > one_hour_ago]
    if len(recent) >= 10:
        return False

    recent.append(now)
    history[user_id] = recent
    save_duel_history(history)
    return True

# Отображение имени
def get_display_name(user):
    return user.first_name or user.username or f"{user.id}"

# Команды
@bot.message_handler(commands=['start'])
def start(message):
    get_balance(message.from_user.id)
    bot.send_message(message.chat.id, "Добро пожаловать в игру Кости 🎲\n\nДоступные команды:\n/balance — баланс\n/daily — ежедневная награда\n/help — помощь")

@bot.message_handler(commands=['add_balance'])
def manual_add_balance(message):
    if message.from_user.id != :
        return bot.reply_to(message, "⛔ У вас нет прав для этой команды.")
    try:
        args = message.text.split()
        user_id = int(args[1])
        amount = int(args[2])
        add_balance(user_id, amount)
        bot.send_message(message.chat.id, f"✅ Пользователю {user_id} добавлено {amount} виртов.")
    except:
        bot.reply_to(message, "⚠️ Использование: /add_balance user_id amount")

@bot.message_handler(commands=['remove_balance'])
def remove_user_balance(message):
    if message.from_user.id != :
        return bot.reply_to(message, "⛔ У вас нет прав для этой команды.")
    try:
        args = message.text.split()
        user_id = int(args[1])
        amount = int(args[2])
        if get_balance(user_id) < amount:
            return bot.send_message(message.chat.id, f"❌ У пользователя {user_id} недостаточно виртов.")
        reduce_balance(user_id, amount)
        bot.send_message(message.chat.id, f"✅ У пользователя {user_id} отнято {amount} виртов.")
    except:
        bot.reply_to(message, "⚠️ Использование: /remove_balance user_id amount")

@bot.message_handler(commands=['daily'])
def daily_reward(message):
    user_id = str(message.from_user.id)
    daily_data = load_daily_data()
    today = datetime.now().strftime('%Y-%m-%d')

    if daily_data.get(user_id) == today:
        bot.send_message(message.chat.id, "⏳ Вы уже получили ежедневную награду сегодня. Попробуйте завтра.")
        return

    add_balance(user_id, DAILY_REWARD)
    daily_data[user_id] = today
    save_daily_data(daily_data)

    bot.send_message(message.chat.id, f"🎁 Вы получили {DAILY_REWARD} виртов! Возвращайтесь завтра за новой наградой.")

@bot.message_handler(commands=['help'])
def help_cmd(message):
    if message.chat.type != 'private':
        return
    text = """
🎲 *Правила игры в кости:*

- `кости 400` — вызов на дуэль (ответом на сообщение)
- `вирты 500` — передать вирты (ответом на сообщение)
- /balance — посмотреть баланс
- /daily — ежедневная награда (500 виртов)

Минимальная ставка — 300. Баланс сохраняется.
"""
    bot.send_message(message.chat.id, text, parse_mode="Markdown")

@bot.message_handler(commands=['balance'])
def balance(message):
    bal = get_balance(message.from_user.id)
    bot.send_message(message.chat.id, f"Ваш баланс: {bal} виртов")

@bot.message_handler(commands=['top'])
def top_players(message):
    balances = load_balances()
    top = sorted(balances.items(), key=lambda x: x[1], reverse=True)[:10]
    text = "🏆 Топ игроков по балансу:\n"
    for i, (user_id, bal) in enumerate(top, 1):
        try:
            user = bot.get_chat_member(message.chat.id, int(user_id)).user
            name = get_display_name(user)
        except:
            name = f"User {user_id}"
        text += f"{i}. {name}: {bal} виртов\n"
    bot.send_message(message.chat.id, text)

# Дуэль
@bot.message_handler(func=lambda m: m.reply_to_message and m.text.lower().startswith('кости'))
def duel_handler(message):
    try:
        bet = int(message.text.split()[1])
        if bet < MIN_BET:
            return bot.reply_to(message, f"Минимальная ставка: {MIN_BET}")
    except:
        return bot.reply_to(message, "Формат: кости 400")

    challenger = message.from_user
    opponent = message.reply_to_message.from_user

    if challenger.id == opponent.id:
        return bot.reply_to(message, "Нельзя вызвать самого себя")

    if get_balance(challenger.id) < bet or get_balance(opponent.id) < bet:
        return bot.reply_to(message, "У кого-то недостаточно виртов")

    if not can_duel(challenger.id):
        return bot.reply_to(message, "⏳ Лимит дуэлей: не более 4 в час. Попробуйте позже.")

    duel_id = f"{challenger.id}:{opponent.id}:{message.chat.id}"
    pending_duels[duel_id] = {'bet': bet}

    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton("✅ Принять", callback_data=f"accept:{duel_id}"),
        types.InlineKeyboardButton("❌ Отказаться", callback_data=f"decline:{duel_id}")
    )

    msg = bot.send_message(message.chat.id, f"{get_display_name(challenger)} вызвал {get_display_name(opponent)} на дуэль на {bet} виртов 🎲", reply_markup=markup)
    pending_duels[duel_id]['msg_id'] = msg.message_id

# Обработка кнопок
@bot.callback_query_handler(func=lambda call: True)
def callback(call):
    data = call.data
    if ":" not in data:
        return
    action, duel_id = data.split(":", 1)
    if duel_id not in pending_duels:
        return

    challenger_id, opponent_id, chat_id = map(int, duel_id.split(":"))
    if call.from_user.id != opponent_id:
        return

    bet = pending_duels[duel_id]['bet']
    challenger_name = f"User {challenger_id}"
    opponent_name = get_display_name(call.from_user)

    try:
        challenger = bot.get_chat_member(chat_id, challenger_id).user
        challenger_name = get_display_name(challenger)
    except:
        pass

    if action == "accept":
        user1_roll = random.randint(1, 6)
        user2_roll = random.randint(1, 6)

        result = f"🎲 Результаты дуэли на {bet} виртов:\n"
        result += f"{opponent_name} выбросил: {user2_roll}\n"
        result += f"{challenger_name} выбросил: {user1_roll}\n"

        if user1_roll > user2_roll:
            winner = challenger_id
            loser = opponent_id
        elif user2_roll > user1_roll:
            winner = opponent_id
            loser = challenger_id
        else:
            result += "Ничья! Вирты возвращены."
            bot.edit_message_reply_markup(chat_id, pending_duels[duel_id]['msg_id'], reply_markup=None)
            bot.send_message(chat_id, result)
            del pending_duels[duel_id]
            return

        add_balance(winner, bet)
        reduce_balance(loser, bet)

        winner_name = challenger_name if winner == challenger_id else opponent_name
        result += f"🏆 Победил: {winner_name}"
        bot.edit_message_reply_markup(chat_id, pending_duels[duel_id]['msg_id'], reply_markup=None)
        bot.send_message(chat_id, result)
        del pending_duels[duel_id]

    elif action == "decline":
        bot.edit_message_text("❌ Дуэль отклонена.", chat_id, pending_duels[duel_id]['msg_id'])
        del pending_duels[duel_id]

# Передача виртов
@bot.message_handler(func=lambda m: m.reply_to_message and m.text.lower().startswith('вирты'))
def transfer(message):
    try:
        amount = int(message.text.split()[1])
        if amount <= 0:
            return
    except:
        return

    sender = message.from_user
    receiver = message.reply_to_message.from_user

    if sender.id == receiver.id:
        return

    if get_balance(sender.id) < amount:
        return bot.reply_to(message, "Недостаточно виртов")

    reduce_balance(sender.id, amount)
    add_balance(receiver.id, amount)
    bot.send_message(message.chat.id, f"{get_display_name(sender)} передал {amount} виртов {get_display_name(receiver)}")

@bot.message_handler(commands=['reset_balances'])
def reset_balances(message):
    if message.from_user.id != :
        return bot.reply_to(message, "⛔ У вас нет прав для этой команды.")

    balances = load_balances()
    for user_id in balances.keys():
        balances[user_id] = START_BALANCE
    save_balances(balances)

    bot.send_message(message.chat.id, "✅ Балансы всех пользователей сброшены до стандартного значения.")

# Запуск
print("Бот запущен!")
keep_alive()
bot.infinity_polling()
